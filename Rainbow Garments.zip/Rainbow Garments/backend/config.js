export default {
    MONGODB_URL: process.env.MONGODB_URL || 'mongodb://localhost/rainbow',
    MONGODB_URL: process.env.MONGODB_URL || 'mongodb://localhost/rainbow',
    JWT_SECRET: process.env.JWT_SECRET || 'somethingsecret'
}