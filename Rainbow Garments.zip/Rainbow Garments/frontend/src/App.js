import React from 'react';
import './App.css';
import {BrowserRouter, Route, Link} from 'react-router-dom';
import HomeScreen from './All/Screens/HomeScreen';
import ProductScreen from './All/Screens/ProductScreen';
import CartScreen from './All/Screens/CartScreen';
import SigninScreen from './All/Screens/SigninScreen';
import { useSelector } from 'react-redux';
import RegisterScreen from './All/Screens/RegisterScreen';
import ProductsScreen from './All/Screens/ProductsScreen';
import ShippingScreen from './All/Screens/ShippingScreen';
import PaymentScreen from './All/Screens/PaymentScreen';
import PlaceOrderScreen from './All/Screens/PlaceOrderScreen';
import OrderScreen from './All/Screens/OrderScreen';
import OrdersScreen from './All/Screens/OrdersScreen';
import ProfileScreen from './All/Screens/ProfileScreen';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';


function App() {
  const cart =useSelector(state => state.cart);
  const {cartItems} =cart;
  const userSignin = useSelector(state => state.userSignin);
  const { userInfo } = userSignin;

  const openMenu = () => {
    document.querySelector(".sidebar").classList.add("open");
  }
  const closeMenu = () => {
    document.querySelector(".sidebar").classList.remove("open");
  }
  return <BrowserRouter>
   <div className="grid-container" >
     <header className="header" >
       <div className="brand">
       <button onClick={openMenu} >
         &#9776; 
       </button>
       <Link to="/"> &#x1F308; Rainbow</Link>
       </div>
       <div className="header-links">
       <Link to="/cart"> <ShoppingCartIcon fontSize="large"/> {" "}<span className="number">{cartItems.length}</span></Link>{" "}
            {
              userInfo ? <Link to="/profile">{userInfo.name}</Link> :
                <Link to="/signin">Sign In</Link>
            }
   
         {
           userInfo && userInfo.isAdmin && (
             <div className="dropdown">
             <a href="#" >Admin</a>
             <ul className="dropdown-content">
               <li>
                 <Link to="/orders">Orders</Link>
                 <Link to="/products">Products</Link>
               </li>
             </ul>
             </div>
           ) 
         }
       </div>
    </header>
    <aside className="sidebar">
      <h2> Hello ! {userInfo ?<span  className="uname">{userInfo.name}</span> :
                  " "}
        <button className="sidebar-close-button" onClick={closeMenu}>x</button>
      </h2>
      <ul className="categories">
        <li>
          <Link to="/category/Boys">For Boys</Link>
        </li>
        <li>
          <Link to="/category/Girls">For Girls</Link>
        </li>
        <li>
          <Link to="/category/Bottles">For Bottles</Link>
        </li>
      </ul>
    </aside>
    <main className="main" onClick={closeMenu}>
      <div className="content">
            <Route path="/products" component={ProductsScreen} />
            <Route path="/orders" component={OrdersScreen} />
            <Route path="/shipping" component={ShippingScreen} />
            <Route path="/profile" component={ProfileScreen} />
            <Route path="/signin" component={SigninScreen} />
            <Route path="/register" component={RegisterScreen} />
            <Route path="/payment" component={PaymentScreen} />
            <Route path="/placeorder" component={PlaceOrderScreen} />
            <Route path="/order/:id" component={OrderScreen} />
            <Route path="/product/:id" component={ProductScreen} />
            <Route path="/cart/:id?" component={CartScreen} />
            <Route path="/category/:id" component={HomeScreen} />
            <Route path="/" exact={true} component={HomeScreen} />    
      </div>
     
    </main>
    
    <footer className="footer">
      All rights reserved
    </footer>
   </div>
   </BrowserRouter>
    
  }


export default App;
