import Rater from 'react-rater';
import 'react-rater/lib/react-rater.css';
import React from 'react';

export default function Stars() {
  return (<Rater total={5} rating={0} />)
};
