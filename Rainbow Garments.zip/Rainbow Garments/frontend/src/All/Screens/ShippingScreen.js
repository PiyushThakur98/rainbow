import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { saveShipping } from '../actions/cartActions';
import CheckoutSteps from '../components/CheckoutSteps';

function ShippingScreen(props) {

  const [address, setAddress] = useState('');
  const [line1, setLine1] = useState('');
  const [line2, setLine2] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const dispatch = useDispatch();
 
 
  const submitHandler = (e) => {
    e.preventDefault();
    dispatch(saveShipping({address, line1, line2, state, postalCode}));
    props.history.push('payment')
  }
  return <div>
  <CheckoutSteps step1 step2 />
  <div className="form">
    <form onSubmit={submitHandler} >
      <ul className="form-container">
        <li>
          <h2>Shipping</h2>
        </li>
        <li>
          <label htmlFor="address">
            Address
          </label>
          <input type="text" name="address" id="address" required="true" onChange={(e) => setAddress(e.target.value)}>
          </input>
        </li>
        <li>
          <label htmlFor="line1">
            Address Line 1
          </label>
          <input type="text" name="line1" id="line1" required="true" onChange={(e) => setLine1(e.target.value)}>
          </input>
        </li>
        <li>
          <label htmlFor="line2">
            Address Line 2
          </label>
          <input type="text" name="line2" id="line2" required="true" onChange={(e) => setLine2(e.target.value)}>
          </input>
        </li>
        <li>
          <label htmlFor="state">
            State
          </label>
          <input type="text" name="state" id="state" required="true" onChange={(e) => setState(e.target.value)}>
          </input>
        </li>
        <li>
          <label htmlFor="postalCode">
            Postal Code
          </label>
          <input type="text" name="postalCode" id="postalCode" required="true" onChange={(e) => setPostalCode(e.target.value)}>
          </input>
        </li>

        <li>
          <button type="submit" className="button primary">Continue</button>
        </li>
      </ul>
    </form>
  </div>
  </div>
}
export default ShippingScreen; 