import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { signin } from '../actions/userActions';
import { saveOrdert, listOrders, deleteOrder } from '../actions/orderActions';
import Loading from '../components/Loading';
import DeleteForeverRoundedIcon from '@material-ui/icons/DeleteForeverRounded';

function OrdersScreen(props) {
 const orderList = useSelector(state => state.orderList);
  const { loading, orders, error } = orderList;

  const orderDelete = useSelector(state => state.orderDelete);
  const { loading: loadingDelete, success: successDelete, error: errorDelete } = orderDelete;
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(listOrders());
    return () => {
      //
    };
  }, [successDelete]);


  const deleteHandler = (order) => {
    dispatch(deleteOrder(order._id));
    window.alert('Order Deleted');
  }
  return loading? <Loading/> :
  <div className="content content-margined">

    <div className="order-header">
      <h3>Orders</h3>
      </div>
    
    <div className="order-list">

      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Total Price</th>
            <th>User</th>
            <th>Delivered</th>
            <th>Delivered At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {

          orders.map(order => (<tr key={order._id}>
            <td>{order._id}</td>
            <td>{order.createdAt}</td>
            <td>{order.totalPrice}</td>
            <td>{order.user.name}</td>
            <td>{order.isDelivered.toString()}</td>
            <td>{order.deliveredAt}</td>
            <td>
              <Link to={"/order/"+ order._id} className="button secondary"> Details </Link>
              {' '}
              <button type="button" onClick={()=> deleteHandler(order)} className="button delete"><DeleteForeverRoundedIcon fontSize="large"/></button>
              </td>
            
          </tr>))}
        </tbody>
      </table>

    </div>
  </div>
}
export default OrdersScreen; 