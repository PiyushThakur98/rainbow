import React, { useEffect } from 'react';
import { addToCart, removeFromCart } from '../actions/cartActions';
import { useDispatch, useSelector } from 'react-redux';
import {Link} from 'react-router-dom';
import CheckoutSteps from '../components/CheckoutSteps';
import { createOrder, detailsOrder } from '../actions/orderActions';
import Loading from '../components/Loading';

function OrderScreen (props){
const dispatch = useDispatch();
    useEffect(() => {
        dispatch(detailsOrder(props.match.params.id));
        return () => {
            
        }
    }, []);
        
    const userSignin = useSelector(state => state.userSignin);
    const { userInfo } = userSignin;
    const orderDetails = useSelector(state => state.orderDetails);
    const {loading, success, error, order }= orderDetails;
    const payHandler= () =>{
        props.history.push("/profile");
    };
    const homescreenHandler= () =>{
        props.history.push("/");
    };
    
return( loading? <Loading/> : error? <div>{error}</div> :
    <div>
        <div className="placeorder">
            <div className="placeorder-info">
                <div>
                    <h3>Shipping</h3>to:{userInfo.isAdmin?" ":  <span className="uname">{userInfo.name}</span>}
                    <div>at: {order.shipping.address}, {order.shipping.line1}, {order.shipping.line2}, {order.shipping.state}-{order.shipping.postalCode}</div>
                </div>
                <div>
                    {order.isDelivered? "Delivered at"+ order.deliveredAt : "Not Delivered"}
                </div>
                <div>
                    <h3>Payment</h3>
                    <div>
                        Payment Method: {order.payment.paymentMethod}
                    </div>
                </div>
                <div>
                    {order.isPaid? "Paid at"+ order.PaidAt : "Not Paid"}
                </div>
                <div>
                <ul className="cart-list-container">
                    <li>
                        <h3>
                            Shopping Cart
                        </h3>
                        <div>
                            Price:
                        </div> 
                    </li>

                        {
                        order.orderItems.length === 0? <div> Cart is Empty </div> :
                        order.orderItems.map(item =>       
                            <li>
                                <div className="cart-image"> 
                                <img src={item.image} alt="image"/> 
                                </div>    
                                <div className="cart-name">
                                    <div>
                                        <Link to={"/product/"+ item.product}>
                                            {item.name}
                                        </Link>
                                    </div>   
                                <div>
                                    Qty: {item.qty}
                                       
                                </div>
                                </div>
                                <div className="cart-price">
                                    &#x20B9; {item.price}/-
                                </div>  
                            </li>            
                            )
                        }   
                </ul>
                </div>
                
            </div>
            <div className="placeorder-action">
                <ul>
                    <li>
                        <button onClick={payHandler} className="button primary full-width">See Orders</button>
                    </li>
                    <li>
                        <button onClick={homescreenHandler} className="button primary full-width">Continue Shopping</button>
                    </li>
                    <li><h3>Order Placed</h3></li>
                    <li>
                        <div>Items</div>
                    <div>&#x20B9; {order.itemsPrice}/-</div>
                    </li>
                    <li>
                        <div>Shipping</div>
                    <div>&#x20B9; {order.shippingPrice}/-</div>
                    </li>
                    <li>
                        <div>GST(18%)</div>
                    <div>&#x20B9; {order.gstPrice}/-</div>
                    </li>
                    <li>
                        <div>Order Total</div>
                    <div>&#x20B9; {order.totalPrice}/-</div>
                    </li>
                    <li>
                        <div>Order Total</div>
                    <div>&#x20B9; {order.totalPrice}/-</div>
                    </li>
                    <li>
                        <h4>For more details you can contact us on:</h4>
                    </li>
                    <li>    
                        <button className="button secondary full-width">9811600557</button>
                    </li>
                    <li>    
                        <button className="button secondary full-width">rainbow@gmail.com</button>
                    </li>
                </ul>
           
            </div>
        </div>
    </div>
        

    )
}

export default OrderScreen;