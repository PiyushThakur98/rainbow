import React, { useEffect } from 'react';
import { addToCart, removeFromCart } from '../actions/cartActions';
import { useDispatch, useSelector } from 'react-redux';
import {Link} from 'react-router-dom';
import CheckoutSteps from '../components/CheckoutSteps';
import { createOrder } from '../actions/orderActions';

function PlaceOrderScreen (props){
    
    const userSignin = useSelector(state => state.userSignin);
    const { userInfo } = userSignin;

    const cart =useSelector(state => state.cart);
    const orderCreate = useSelector(state => state.orderCreate);
    const {loading, success, error, order}= orderCreate;
    const { cartItems, shipping, payment } = cart;
    if(!shipping.address){
        props.history.push("/shipping");
    } else if(!payment.paymentMethod){
        props.history.push("/payment");
    }
    const itemsPrice= cartItems.reduce((a,c) => a + c.price*c.qty, 0);
    const shippingPrice= itemsPrice > 500 ? 0 : 100;
    const gstPrice = 0.18* itemsPrice; 
    const totalPrice=  itemsPrice+ shippingPrice+ gstPrice;
    const dispatch = useDispatch();
    
    const PlaceOrderHandler = () =>{    
        dispatch(createOrder({orderItems: cartItems, shipping, payment, itemsPrice, shippingPrice, gstPrice, totalPrice}));
    }
    useEffect(() => {
      if(success){
          props.history.push("/order/" + order._id);
          window.alert("Your Order Is Placed");
      }
    }, [success]);  

    return(
    <div>
        <CheckoutSteps step1 step2 step3 step4/>
        <div className="placeorder">
            <div className="placeorder-info">
                <div>
                    <h3>Shipping</h3>to:{userInfo.isAdmin?" ":  <span className="uname">{userInfo.name}</span>}
                    <div>{cart.shipping.address}, {cart.shipping.line1}, {cart.shipping.line2}, {cart.shipping.state}-{cart.shipping.postalCode}</div>
                </div>
                <div>
                    <h3>Payment</h3>
                    <div>
                        Payment Method: {cart.payment.paymentMethod}
                    </div>
                </div>
                <div>
                <ul className="cart-list-container">
                    <li>
                        <h3>
                            Shopping Cart
                        </h3>
                        <div>
                            Price:
                        </div> 
                    </li>

                        {
                        cartItems.length === 0? <div> Cart is Empty </div> :
                        cartItems.map(item =>       
                            <li>
                                <div className="cart-image"> 
                                <img src={item.image} alt="image"/> 
                                </div>    
                                <div className="cart-name">
                                    <div>
                                        <Link to={"/product/"+ item.product}>
                                            {item.name}
                                        </Link>
                                    </div>   
                                <div>
                                    Qty: {item.qty}
                                       
                                </div>
                                </div>
                                <div className="cart-price">
                                    &#x20B9; {item.price}/-
                                </div>  
                            </li>            
                            )
                        }   
                </ul>
                </div>
                
            </div>
            <div className="placeorder-action">
                <ul>
                    <li>
                        <button onClick={PlaceOrderHandler} className="button primary full-width">Place Order</button>
                    </li>
                    <li><h3>Order Summary</h3></li>
                    <li>
                        <div>Items</div>
                    <div>&#x20B9; {itemsPrice}/-</div>
                    </li>
                    <li>
                        <div>Shipping</div>
                    <div>&#x20B9; {shippingPrice}/-</div>
                    </li>
                    <li>
                        <div>GST(18%)</div>
                    <div>&#x20B9; {gstPrice}/-</div>
                    </li>
                    <li>
                        <div>Order Total</div>
                    <div>&#x20B9; {totalPrice}/-</div>
                    </li>
                </ul>
           
            </div>
        </div>
    </div>
        

    )
}

export default PlaceOrderScreen;