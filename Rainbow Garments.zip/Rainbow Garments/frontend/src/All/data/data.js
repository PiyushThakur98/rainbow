export default {
  products:[{
    _id: '1',
    name: 'T-Shirt',
    category: 'Boy',
    image: 'https://wallpapercave.com/wp/wp2058291.jpg',
    price: '200',
    brand: 'MeMe',
    rating: '4.5',
    numReviews: 10
  },
  {
    _id: '2',
    name: 'Jeans',
    category: 'Boy',
    image: 'https://wallpapercave.com/wp/wp2058291.jpg',
    price: '500',
    brand: 'MeMe',
    rating: '4',
    numReviews: 13
  },
  {
    _id: '3',
    name: 'Top',
    category: 'Girl',
    image: 'https://wallpapercave.com/wp/wp2058291.jpg',
    price: '250',
    brand: 'MeMe',
    rating: '4',
    numReviews: 16
  },
]
}